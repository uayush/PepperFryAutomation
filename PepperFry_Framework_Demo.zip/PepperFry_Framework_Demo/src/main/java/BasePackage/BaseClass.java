package BasePackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;

public class BaseClass {
	public WebDriver driver;
	public static Properties prop;
	
	public void readConfigFile() throws IOException{
		prop = new Properties();
		FileInputStream fin = new FileInputStream("C:\\Users\\NDATRG\\Desktop\\selenium training\\PepperFry_Framework_Demo\\src\\main\\java\\ConfigPackage\\config.properties");
		prop.load(fin);
	}
	
	@BeforeMethod
	public void initialization() throws IOException {
		readConfigFile();
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
}
