package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import BasePackage.BaseClass;

public class Login extends BaseClass {
	WebDriver driver;
	@FindBy(how = How.LINK_TEXT, using = "Login")
	public static WebElement loginButton;
	
	@FindBy(how = How.NAME, using = "user[new]")
	public static WebElement username;
	
	@FindBy(how = How.NAME, using = "passowrd")
	public static WebElement pwd;
	
	@FindBy(how = How.LINK_TEXT, using = "SIGN IN")
	public static WebElement SignIn;

	public Login(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void LoginPepperFry(String user, String password){
		loginButton.click();
		username.sendKeys(user);
		pwd.sendKeys(password);
		SignIn.click();
	}
}
