package Tests;

import org.testng.annotations.Test;

import BasePackage.BaseClass;
import PageObjects.Login;

public class Login_Test extends BaseClass
{
Login loginObj;	

@Test
public void loginPepperfry(){
	loginObj = new Login(driver);
	loginObj.LoginPepperFry(prop.getProperty("userName"), prop.getProperty("password"));
}


}
